<?php
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; Filename = History_Report.xls");

require 'data.php';
?>
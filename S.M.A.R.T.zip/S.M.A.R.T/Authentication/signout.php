<?php

    session_destroy();
    header("Location: /S.M.A.R.T/index.html");
    exit;

?>
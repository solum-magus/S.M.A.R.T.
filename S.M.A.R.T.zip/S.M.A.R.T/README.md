# S.M.A.R.T.
School Maintenance and Real-time Tracking
